<?php
/**
 * PrestaShop Server-Side GA4 - WERSJA v3.3.0 (FIXED)
 * - Przywrócone oryginalne klucze API
 * - Statusy: 34, 2, 4, 21 + flaga "paid"
 * - Fix: Zwiększony timeout do 5s
 * - Fix: Debug Mode (widoczne w GA4 DebugView)
 * - Fix: Szczegółowe logi błędów/sukcesów
 */

if (!defined('_PS_VERSION_'))
    exit;

class DataLayer extends Module
{
    // --- TWOJE DANE (PRZYWRÓCONE Z ORYGINAŁU) ---
    const GA4_MEASUREMENT_ID = 'G-LM6KRYGMJ3'; 
    const GA4_API_SECRET = 'G5BdndspT36KnbXee_Z1rg';
    // --------------------------------------------

    public function __construct()
    {
        $this->name = 'datalayer';
        $this->tab = 'analytics_stats';
        $this->version = '3.3.0';
        $this->author = 'petrovv77 & Gemini (Fixed)';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Data Layer & Server-Side GA4 (PRO - Fixed)');
        $this->description = $this->l('Profesjonalny tracking Server-Side. Obsługa P24, BLIK i Enhanced Conversions.');
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    }

    public function install()
    {
        if (!parent::install() ||
            !$this->registerHook('displayHeader') ||             
            !$this->registerHook('actionCartSave') ||
            !$this->registerHook('actionValidateOrder') ||
            !$this->registerHook('actionObjectOrderAddAfter') || 
            !$this->registerHook('actionOrderStatusPostUpdate') ||
            !$this->registerHook('actionCartUpdateQuantityBefore')
        ) {
            return false;
        }
        
        $sql1 = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'data_layer` (
            `id_data_layer` int(11) NOT NULL AUTO_INCREMENT,
            `id_order` int(11) NOT NULL,
            `sent` tinyint(1) DEFAULT NULL,
            `date_add` datetime DEFAULT NULL,
            PRIMARY KEY (`id_data_layer`),
            KEY `id_order` (`id_order`),
            KEY `sent` (`sent`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';

        $sql2 = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'data_layer_cart` (
            `id_cart` int(11) NOT NULL,
            `google_gclid` VARCHAR(255) NULL,
            `google_ga_id` VARCHAR(255) NULL,
            `date_add` datetime DEFAULT NULL,
            PRIMARY KEY (`id_cart`)
        ) ENGINE='._MYSQL_ENGINE_.' DEFAULT CHARSET=utf8;';

        try { Db::getInstance()->execute("ALTER TABLE `"._DB_PREFIX_."orders` ADD COLUMN `google_gclid` VARCHAR(255) NULL DEFAULT NULL"); } catch (Exception $e) {}
        try { Db::getInstance()->execute("ALTER TABLE `"._DB_PREFIX_."orders` ADD COLUMN `google_ga_id` VARCHAR(255) NULL DEFAULT NULL"); } catch (Exception $e) {}

        return Db::getInstance()->execute($sql1) && Db::getInstance()->execute($sql2);
    }

    public function uninstall() { return parent::uninstall(); }

    // --- 1. Łapanie danych ---
    public function hookDisplayHeader() {
        if (Tools::getIsset('gclid')) $this->context->cookie->google_gclid = Tools::getValue('gclid');
        if (isset($_COOKIE['_ga'])) {
            $parts = explode('.', $_COOKIE['_ga']);
            if (count($parts) >= 4) $this->context->cookie->google_ga_id = $parts[2].'.'.$parts[3];
        }
        $this->context->cookie->write();
    }

    public function hookActionCartSave($params) {
        if (isset($this->context->cart->id) && $this->context->cart->id) {
            $gclid = isset($this->context->cookie->google_gclid) ? $this->context->cookie->google_gclid : (Tools::getValue('gclid') ? Tools::getValue('gclid') : null);
            $ga_id = isset($this->context->cookie->google_ga_id) ? $this->context->cookie->google_ga_id : null;
            if ($gclid || $ga_id) {
                Db::getInstance()->execute("INSERT INTO `"._DB_PREFIX_."data_layer_cart` (id_cart, google_gclid, google_ga_id, date_add) VALUES (".(int)$this->context->cart->id.", '".pSQL($gclid)."', '".pSQL($ga_id)."', NOW()) ON DUPLICATE KEY UPDATE google_gclid = VALUES(google_gclid), google_ga_id = VALUES(google_ga_id)");
            }
        }
    }

    // --- 2. Przypisywanie do Zamówienia ---
    public function hookActionObjectOrderAddAfter($params) { if (isset($params['object']) && $params['object'] instanceof Order) $this->saveTrackingDataToOrder($params['object']); }
    public function hookActionValidateOrder($params) { $this->saveTrackingDataToOrder($params['order']); }
    
    private function saveTrackingDataToOrder($order) {
        $cart_data = Db::getInstance()->getRow("SELECT * FROM `"._DB_PREFIX_."data_layer_cart` WHERE id_cart = ".(int)$order->id_cart);
        $gclid = $cart_data['google_gclid'] ?? ($this->context->cookie->google_gclid ?? null);
        $ga_id = $cart_data['google_ga_id'] ?? ($this->context->cookie->google_ga_id ?? null);
        
        $sql_set = [];
        if ($gclid) $sql_set[] = "google_gclid = '".pSQL($gclid)."'";
        if ($ga_id) $sql_set[] = "google_ga_id = '".pSQL($ga_id)."'";
        
        if (!empty($sql_set)) {
            Db::getInstance()->execute("UPDATE "._DB_PREFIX_."orders SET ".implode(',', $sql_set)." WHERE id_order = ".(int)$order->id);
        }
    }

    // --- 3. Wysyłka Server-Side (Finalizacja) ---
    public function hookActionOrderStatusPostUpdate($params)
    {
        $sid = $params['newOrderStatus']->id;
        
        // TRIGGERY:
        // ID 2  = Płatność zaakceptowana
        // ID 4  = Wysłane
        // ID 21 = Paczka gotowa do wysłania
        // ID 34 = Płatność Przelewy24 (Twoje ustawienie)
        // Config Payment = Główny status
        // Paid Flag = Dowolny opłacony
        if ($sid == 2 || $sid == 4 || $sid == 21 || $sid == 34 || $sid == Configuration::get('PS_OS_PAYMENT') || $params['newOrderStatus']->paid == 1) {
            
            $order = new Order((int)$params['id_order']);
            $already_sent = Db::getInstance()->getValue('SELECT sent FROM `'._DB_PREFIX_.'data_layer` WHERE id_order = '.(int)$order->id);
            
            if (!$already_sent) {
                $tracking_data = Db::getInstance()->getRow('SELECT google_gclid, google_ga_id FROM `'._DB_PREFIX_.'orders` WHERE id_order = '.(int)$order->id);
                
                // Awaryjne pobranie z mapy koszyka
                if (empty($tracking_data['google_gclid'])) {
                     $cart_fix = Db::getInstance()->getRow("SELECT google_gclid, google_ga_id FROM `"._DB_PREFIX_."data_layer_cart` WHERE id_cart = ".(int)$order->id_cart);
                     if ($cart_fix) $tracking_data = $cart_fix;
                }

                $override_ids = [];
                if (!empty($tracking_data['google_gclid'])) $override_ids['gclid'] = $tracking_data['google_gclid'];
                if (!empty($tracking_data['google_ga_id'])) $override_ids['client_id'] = $tracking_data['google_ga_id'];
                
                // [WAŻNE FIX] Zakomentowane, żeby testy bez ciasteczek też przechodziły (generuje guest_ID)
                // if (empty($override_ids)) return;

                // Haszowanie maila
                $customer = new Customer((int)$order->id_customer);
                if (Validate::isLoadedObject($customer)) {
                    $override_ids['user_data'] = ['sha256_email_address' => [hash('sha256', strtolower(trim($customer->email)))]];
                }

                $products_list = [];
                foreach ($order->getProducts() as $product) {
                    $products_list[] = [
                        'item_id' => (string)$product['product_id'],
                        'item_name' => $product['product_name'],
                        'quantity' => (int)$product['product_quantity'],
                        'price' => (float)$product['unit_price_tax_incl'] // Upewnienie się co do typu tablicy
                    ];
                }

                $http_code = $this->sendGa4Event('purchase', [
                    'currency' => 'PLN', 
                    'value' => (float)$order->total_paid,
                    'transaction_id' => (string)$order->reference,
                    'shipping' => (float)$order->total_shipping,
                    'tax' => (float)($order->total_paid_tax_incl - $order->total_paid_tax_excl),
                    'items' => $products_list
                ], $override_ids);

                if ($http_code >= 200 && $http_code < 300) {
                    Db::getInstance()->execute('INSERT INTO `'._DB_PREFIX_.'data_layer` (id_order, sent, date_add) VALUES ('.(int)$order->id.', 1, NOW()) ON DUPLICATE KEY UPDATE sent=1');
                }
            }
        }
    }

    public function hookActionCartUpdateQuantityBefore($params) {
        if (isset($params['operator']) && $params['operator'] == 'up') {
            $this->hookActionCartSave([]); 
            $product = new Product((int)$params['id_product'], false, $this->context->language->id);
            $this->sendGa4Event('add_to_cart', [
                'currency' => $this->context->currency->iso_code,
                'value' => (float)$product->getPrice(true) * (int)$params['quantity'],
                'items' => [['item_id' => (string)$product->id, 'item_name' => $product->name, 'quantity' => (int)$params['quantity'], 'price' => (float)$product->getPrice(true)]]
            ]);
        }
    }

    private function sendGa4Event($eventName, $params, $override_ids = [])
    {
        // Fix: Fallback na losowe ID jeśli brak ciasteczka (dla testów)
        $cid = $override_ids['client_id'] ?? ($this->context->cookie->google_ga_id ?? 'guest_'.rand(1000,9999));
        if (isset($override_ids['gclid'])) $params['gclid'] = $override_ids['gclid'];

        // Fix: Włączenie trybu debugowania dla GA4
        $params['debug_mode'] = 1;

        $payload = ['client_id' => $cid, 'events' => [['name' => $eventName, 'params' => $params]]];
        if (isset($override_ids['user_data'])) $payload['events'][0]['params']['user_data'] = $override_ids['user_data'];

        // Serializacja do logów
        $json_payload = json_encode($payload);

        $ch = curl_init("https://www.google-analytics.com/mp/collect?measurement_id=".self::GA4_MEASUREMENT_ID."&api_secret=".self::GA4_API_SECRET);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_payload);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        // Fix: Zwiększony timeout do 5 sekund
        curl_setopt($ch, CURLOPT_TIMEOUT_MS, 5000);
        
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'PrestaShop Server Agent';
        // Opcjonalne wyłączenie wysyłania IP serwera (możesz odkomentować jeśli wciąż będą problemy)
        $user_ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? ($_SERVER['REMOTE_ADDR'] ?? '');
        
        $headers = ['Content-Type: application/json', 'User-Agent: ' . $user_agent];
        if ($user_ip) { $headers[] = 'X-Forwarded-For: ' . $user_ip; $headers[] = 'X-Real-IP: ' . $user_ip; }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        $responseBody = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        
        // Fix: Pełne logowanie do PrestaShop
        if ($code >= 200 && $code < 300) {
            PrestaShopLogger::addLog("DataLayer SUKCES [$eventName]: Status $code. CID: $cid. Payload: $json_payload", 1);
        } else {
            PrestaShopLogger::addLog("DataLayer BŁĄD [$eventName]: Status $code / Curl: $curlError / Resp: $responseBody", 3);
        }
        
        curl_close($ch);
        return $code;
    }
}