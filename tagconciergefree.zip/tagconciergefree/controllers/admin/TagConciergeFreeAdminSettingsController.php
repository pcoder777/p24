<?php

use PrestaShop\Module\TagConciergeFree\Controller\Admin\SettingsController;

class TagConciergeFreeAdminSettingsController extends SettingsController
{
}
