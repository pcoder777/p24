<?php

use PrestaShop\Module\TagConciergeFree\Controller\AjaxController;

class TagConciergeFreeAjaxModuleFrontController extends AjaxController
{
}
