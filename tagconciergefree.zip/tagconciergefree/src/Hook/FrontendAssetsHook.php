<?php

namespace PrestaShop\Module\TagConciergeFree\Hook;

use Configuration;
use Hook as PrestaShopHook;
use PrestaShop\Module\TagConciergeFree\ValueObject\ConfigurationVO;

class FrontendAssetsHook extends AbstractHook
{
    /** @var array */
    public const HOOKS = [
        Hooks::DISPLAY_HEADER => [
            'loadHeaderAssets',
            'loadGtmScript',
        ],
        Hooks::DISPLAY_AFTER_BODY_OPENING_TAG => [
            'loadGtmFrame',
        ],
        Hooks::DISPLAY_BEFORE_BODY_CLOSING_TAG => [
            'loadFooterAssets',
        ],
    ];

    public function loadHeaderAssets(): string
    {
        return $this->module->render('hooks/frontend_assets/display_header.tpl');
    }

    public function loadGtmScript(): string
    {
        return PrestaShopHook::exec(Hooks::TC_DISPLAY_BEFORE_GTM_HEAD_SNIPPET) . Configuration::get(ConfigurationVO::GTM_CONTAINER_SNIPPET_HEAD);
    }

    public function loadGtmFrame(): string
    {
        return Configuration::get(ConfigurationVO::GTM_CONTAINER_SNIPPET_BODY);
    }

    public function loadFooterAssets(): string
    {
        return $this->module->render('hooks/frontend_assets/display_before_body_closing_tag.tpl');
    }
}
