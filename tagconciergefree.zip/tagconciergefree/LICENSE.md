2023 Tag Concierge

NOTICE OF LICENSE

This source file is subject to the Academic Free License 3.0 (AFL-3.0)
that is bundled with this package in the file LICENSE.
It is also available through the world-wide-web at this URL:
https://opensource.org/licenses/AFL-3.0

@author    Tag Concierge <contact@tagconcierge.com>
@copyright 2023 Tag Concierge
@license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
